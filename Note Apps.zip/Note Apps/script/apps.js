class AppBar extends HTMLElement {
    _shadowRoot = null;

    constructor() {
      super();
      this._shadowRoot = this.attachShadow({ mode: 'open' });
      this.shadowRoot.innerHTML = `
        <style>
          header {
            background-color: #FF204E;
            color: #fff;
            padding: 10px;
            text-align: center;
          }
        </style>
        <header>
          <h1>Notes App</h1>
        </header>
      `;
    }
  }
  
  class NoteForm extends HTMLElement {
    constructor() {
      super();
      this.attachShadow({ mode: 'open' });
      this.shadowRoot.innerHTML = `
        <style>
          form {
            margin: 20px;
          }
          label {
            display: grid;
            margin-bottom: 5px;
          }
          input[type="text"],
          textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            box-sizing: border-box;
          }
          input[type="submit"] {
            padding: 8px 16px;
            background-color: #A0153E;
            color: white;
            border: none;
            cursor: pointer;
          }
        </style>
        <form id="noteForm">
          <label for="title">Masukan Catatan</label>
          <input type="text" id="title" required>
          <label for="body">Isi Catatan</label>
          <textarea id="body" required></textarea>
          <input type="submit" value="Add Note">
        </form>
      `;
    }
  
    connectedCallback() {
      this.shadowRoot.getElementById('noteForm').addEventListener('submit', this.addNote.bind(this));
    }
  
    addNote(event) {
      event.preventDefault();
      const titleInput = this.shadowRoot.getElementById('title');
      const bodyInput = this.shadowRoot.getElementById('body');
      const title = titleInput.value.trim();
      const body = bodyInput.value.trim();
      if (title === '' || body === '') {
        alert('Mohon untuk mengisi semua kolom');
        return;
      }
      this.dispatchEvent(new CustomEvent('noteAdded', { detail: { title, body } }));
      titleInput.value = '';
      bodyInput.value = '';
    }
  }
  
  class NoteList extends HTMLElement {
    constructor() {
      super();
      this.attachShadow({ mode: 'open' });
      this.notesData = [];
    }
  
    connectedCallback() {
      this.render();
    }
  
    setNotes(notes) {
      this.notesData = notes;
      this.render();
    }
  
    render() {
      this.shadowRoot.innerHTML = `
        <style>
          .list {
            margin: 20px;
          }
          .note {
            background-color: #5D0E41;
            padding: 20px;
            margin-bottom: 10px;
            border-radius: 5px;
            color: white;
          }
          .note h3 {
            margin-top: 0;
          }
          .note p {
            margin-bottom: 0;
          }
        </style>
        <div class="list">
          <h2>Notes List</h2>
          <div id="notesContainer"></div>
        </div>
      `;
      const notesContainer = this.shadowRoot.getElementById('notesContainer');
      this.notesData.forEach(note => {
        const noteDiv = document.createElement('div');
        noteDiv.classList.add('note');
        noteDiv.innerHTML = `
          <h3>${note.title}</h3>
          <p>${note.body}</p>
        `;
        notesContainer.appendChild(noteDiv);
      });
    }
  }

  class FooterBar extends HTMLElement {
    constructor() {
      super();
      this.attachShadow({ mode: 'open' });
      this.shadowRoot.innerHTML = `
        <style>
          footer {
            background-color: #00224D;
            color: #fff;
            padding: 10px;
            text-align: center;
          }
        </style>
        <footer>
            <h2>Dicoding Note Apps</h2>
        </footer>
      `;
    }
  }
  
  customElements.define('app-bar', AppBar);
  customElements.define('note-form', NoteForm);
  customElements.define('note-list', NoteList);
  customElements.define('footer-bar', FooterBar);

  const notesData = [
    {
      id: 'notes-jT-jjsyz61J8XKiI',
      title: 'Welcome to Notes, Dimas!',
      body: 'Welcome to Notes! This is your first note. You can archive it, delete it, or create new ones.',
      createdAt: '2022-07-28T10:03:12.594Z',
      archived: false,
    },
    {
      id: 'notes-aB-cdefg12345',
      title: 'Meeting Agenda',
      body: 'Discuss project updates and assign tasks for the upcoming week.',
      createdAt: '2022-08-05T15:30:00.000Z',
      archived: false,
    },
    {
      id: 'notes-XyZ-789012345',
      title: 'Shopping List',
      body: 'Milk, eggs, bread, fruits, and vegetables.',
      createdAt: '2022-08-10T08:45:23.120Z',
      archived: false,
    },
    {
      id: 'notes-1a-2b3c4d5e6f',
      title: 'Personal Goals',
      body: 'Read two books per month, exercise three times a week, learn a new language.',
      createdAt: '2022-08-15T18:12:55.789Z',
      archived: false,
    },
    {
      id: 'notes-LMN-456789',
      title: 'Recipe: Spaghetti Bolognese',
      body: 'Ingredients: ground beef, tomatoes, onions, garlic, pasta. Steps:...',
      createdAt: '2022-08-20T12:30:40.200Z',
      archived: false,
    },
    {
      id: 'notes-QwErTyUiOp',
      title: 'Workout Routine',
      body: 'Monday: Cardio, Tuesday: Upper body, Wednesday: Rest, Thursday: Lower body, Friday: Cardio.',
      createdAt: '2022-08-25T09:15:17.890Z',
      archived: false,
    },
    {
      id: 'notes-abcdef-987654',
      title: 'Book Recommendations',
      body: "1. 'The Alchemist' by Paulo Coelho\n2. '1984' by George Orwell\n3. 'To Kill a Mockingbird' by Harper Lee",
      createdAt: '2022-09-01T14:20:05.321Z',
      archived: false,
    },
    {
      id: 'notes-zyxwv-54321',
      title: 'Daily Reflections',
      body: 'Write down three positive things that happened today and one thing to improve tomorrow.',
      createdAt: '2022-09-07T20:40:30.150Z',
      archived: false,
    },
    {
      id: 'notes-poiuyt-987654',
      title: 'Travel Bucket List',
      body: '1. Paris, France\n2. Kyoto, Japan\n3. Santorini, Greece\n4. New York City, USA',
      createdAt: '2022-09-15T11:55:44.678Z',
      archived: false,
    },
    {
      id: 'notes-asdfgh-123456',
      title: 'Coding Projects',
      body: '1. Build a personal website\n2. Create a mobile app\n3. Contribute to an open-source project',
      createdAt: '2022-09-20T17:10:12.987Z',
      archived: false,
    },
    {
      id: 'notes-5678-abcd-efgh',
      title: 'Project Deadline',
      body: 'Complete project tasks by the deadline on October 1st.',
      createdAt: '2022-09-28T14:00:00.000Z',
      archived: false,
    },
    {
      id: 'notes-9876-wxyz-1234',
      title: 'Health Checkup',
      body: 'Schedule a routine health checkup with the doctor.',
      createdAt: '2022-10-05T09:30:45.600Z',
      archived: false,
    },
    {
      id: 'notes-qwerty-8765-4321',
      title: 'Financial Goals',
      body: '1. Create a monthly budget\n2. Save 20% of income\n3. Invest in a retirement fund.',
      createdAt: '2022-10-12T12:15:30.890Z',
      archived: false,
    },
    {
      id: 'notes-98765-54321-12345',
      title: 'Holiday Plans',
      body: 'Research and plan for the upcoming holiday destination.',
      createdAt: '2022-10-20T16:45:00.000Z',
      archived: false,
    },
    {
      id: 'notes-1234-abcd-5678',
      title: 'Language Learning',
      body: 'Practice Spanish vocabulary for 30 minutes every day.',
      createdAt: '2022-10-28T08:00:20.120Z',
      archived: false,
    },
  ];
  
  console.log(notesData);

  const noteListElement = document.createElement('note-list');
  noteListElement.setNotes(notesData);
  
  
  document.addEventListener('DOMContentLoaded', function() {
    const header = document.querySelector('header');
    const listContainer = document.querySelector('.list');
    const cardContainer = document.querySelector('.card');
    const footer = document.querySelector('footer');
    
    // Mengecek apakah elemen sudah ada sebelum membuatnya lagi
    if (!header.querySelector('app-bar')) {
      header.appendChild(document.createElement('app-bar'));
    }
    if (!listContainer.querySelector('note-form')) {
      listContainer.appendChild(document.createElement('note-form'));
    }
    if (!cardContainer.querySelector('note-list')) {
      const noteListElement = document.createElement('note-list');
      noteListElement.setNotes(notesData);
      cardContainer.appendChild(noteListElement);
    }
    if (!footer.querySelector('fOoter-bar')) {
        footer.appendChild(document.createElement('footer-bar'));
    }
    

    document.querySelector('note-form').addEventListener('noteAdded', event => {
      const { title, body } = event.detail;
      notesData.push({
        id: `notes-${Math.random().toString(36).substr(2, 10)}`,
        title,
        body,
        createdAt: new Date().toISOString(),
        archived: false,
      });

      document.querySelector('note-list').setNotes(notesData);
    });
  });